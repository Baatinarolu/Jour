import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Settings, c as LayoutDashboard, i as SquareChartGantt, l as BookOpen, o as Plus, r as Trash2, s as List, t as X } from "../_libs/lucide-react.mjs";
import { a as number, c as string, i as literal, n as array, o as object, r as boolean, s as record, t as _enum } from "../_libs/zod.mjs";
import { n as format, t as parseISO } from "../_libs/date-fns.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as ResponsiveContainer, i as Area, n as YAxis, o as Tooltip, r as XAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bt7rnRke.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function moneyRound(n) {
	return Math.round((n + Number.EPSILON) * 100) / 100;
}
function formatMoney(n, withSign = true) {
	const body = Math.abs(moneyRound(n)).toLocaleString("en-US", {
		style: "currency",
		currency: "USD"
	});
	if (!withSign) return n < -.004 ? `−${body}` : body;
	if (n > .004) return `+${body}`;
	if (n < -.004) return `−${body}`;
	return body;
}
function formatR(r) {
	if (r == null || !Number.isFinite(r)) return "—";
	const v = Math.abs(r).toFixed(2);
	if (r > 5e-4) return `+${v}R`;
	if (r < -5e-4) return `−${v}R`;
	return "0.00R";
}
function formatPct(ratio) {
	if (ratio == null || !Number.isFinite(ratio)) return "—";
	return `${Math.round(ratio * 100)}%`;
}
function formatFactor(n) {
	if (n == null) return "—";
	if (!Number.isFinite(n)) return "∞";
	return n.toFixed(2);
}
function formatQty(n) {
	return n.toLocaleString("en-US", { maximumFractionDigits: 4 });
}
function formatPrice(n) {
	const abs = Math.abs(n);
	const max = abs >= 100 ? 2 : abs >= 1 ? 4 : 5;
	return Number(n.toFixed(max)).toLocaleString("en-US", {
		minimumFractionDigits: 2,
		maximumFractionDigits: max
	});
}
function pnlClass(n) {
	if (n > .004) return "text-up";
	if (n < -.004) return "text-down";
	return "text-muted";
}
function dayKey(iso) {
	return format(new Date(iso), "yyyy-MM-dd");
}
function formatDay(iso) {
	return format(new Date(iso), "MMM d");
}
function toDatetimeLocal(iso) {
	const d = new Date(iso);
	const p = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
function fromDatetimeLocal(value) {
	if (!value) return null;
	const d = new Date(value);
	if (Number.isNaN(d.getTime())) return null;
	return d.toISOString();
}
function nowLocalInput() {
	return toDatetimeLocal((/* @__PURE__ */ new Date()).toISOString());
}
function todayKey(now = /* @__PURE__ */ new Date()) {
	return format(now, "yyyy-MM-dd");
}
var MARKET_LABEL = {
	stocks: "Stocks",
	options: "Options",
	futures: "Futures",
	forex: "Forex",
	crypto: "Crypto"
};
var SESSION_LABEL = {
	asia: "Asia",
	london: "London",
	newyork: "New York",
	other: "Other"
};
var SIDE_LABEL = {
	long: "Long",
	short: "Short"
};
function marketLabel(m) {
	return MARKET_LABEL[m];
}
function sessionLabel(s) {
	return SESSION_LABEL[s];
}
function sideLabel(s) {
	return SIDE_LABEL[s];
}
function Tip({ active, payload }) {
	if (!active || !payload?.length) return null;
	const point = payload[0].payload;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-sm border border-border bg-card px-3 py-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: point.key === "start" ? "Start" : point.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-sm tabular-nums",
				children: formatMoney(point.equity, false)
			}),
			point.key !== "start" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-sm tabular-nums text-muted",
				children: [formatMoney(point.dayPnl), " day"]
			}) : null
		]
	});
}
function ChartInner({ points }) {
	const values = points.map((point) => point.equity);
	const min = Math.min(...values);
	const max = Math.max(...values);
	const pad = Math.max(max - min, 1) * .22;
	const domain = [min - pad, max + pad];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
			data: points,
			margin: {
				top: 8,
				right: 8,
				left: 0,
				bottom: 0
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "label",
					axisLine: false,
					tickLine: false,
					minTickGap: 28,
					tick: {
						fill: "var(--color-muted)",
						fontSize: 12
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
					domain,
					axisLine: false,
					tickLine: false,
					width: 52,
					tickCount: 4,
					tickFormatter: (value) => value.toLocaleString("en-US", {
						notation: "compact",
						maximumFractionDigits: 0
					}),
					tick: {
						fill: "var(--color-muted)",
						fontSize: 12,
						fontFamily: "IBM Plex Mono"
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tip, {}),
					cursor: { stroke: "var(--color-border)" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
					type: "monotone",
					dataKey: "equity",
					baseValue: domain[0],
					stroke: "var(--color-accent)",
					strokeWidth: 1.5,
					fill: "var(--color-accent)",
					fillOpacity: .12,
					dot: false,
					activeDot: {
						r: 3,
						fill: "var(--color-accent)",
						stroke: "var(--color-background)"
					}
				})
			]
		})
	});
}
function EquityChart({ points }) {
	const [show, setShow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setShow(true), []);
	if (points.length < 2) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-64 items-center justify-center rounded-xl border border-border bg-card px-6 text-center text-sm text-muted md:h-72",
		children: "Two closed trades draw the equity curve."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-64 flex-col rounded-xl border border-border bg-card p-4 md:h-72",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Equity"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 min-h-0 flex-1",
			children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartInner, { points }) : null
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("press inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm font-medium disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-foreground hover:opacity-90",
			secondary: "border border-border bg-card-2 text-foreground hover:bg-card",
			ghost: "text-muted hover:bg-card-2 hover:text-foreground",
			danger: "bg-down/15 text-down hover:bg-down/25"
		},
		size: {
			md: "h-11 px-4 text-sm",
			sm: "h-11 px-3 text-sm",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function tradePnl(t) {
	return moneyRound((t.side === "long" ? t.exit - t.entry : t.entry - t.exit) * t.quantity - t.fees);
}
function tradeRisk(t) {
	if (t.stop == null || !Number.isFinite(t.stop)) return null;
	const dist = Math.abs(t.entry - t.stop);
	if (dist === 0) return null;
	return moneyRound(dist * t.quantity);
}
function tradeR(t) {
	const risk = tradeRisk(t);
	if (risk == null || risk === 0) return null;
	return tradePnl(t) / risk;
}
function buildEquity(trades, start) {
	const sorted = [...trades].sort((a, b) => new Date(a.closedAt).getTime() - new Date(b.closedAt).getTime());
	const days = [];
	for (const t of sorted) {
		const key = dayKey(t.closedAt);
		const last = days[days.length - 1];
		const pnl = tradePnl(t);
		if (last && last.key === key) last.pnl = moneyRound(last.pnl + pnl);
		else days.push({
			key,
			label: format(new Date(t.closedAt), "MMM d"),
			pnl
		});
	}
	let equity = moneyRound(start);
	const points = [];
	if (days.length) {
		const first = /* @__PURE__ */ new Date(`${days[0].key}T12:00:00`);
		first.setDate(first.getDate() - 1);
		points.push({
			key: "start",
			label: format(first, "MMM d"),
			equity,
			dayPnl: 0
		});
	}
	for (const day of days) {
		equity = moneyRound(equity + day.pnl);
		points.push({
			key: day.key,
			label: day.label,
			equity,
			dayPnl: day.pnl
		});
	}
	return points;
}
function journalStats(trades, startingBalance) {
	const sorted = [...trades].sort((a, b) => new Date(a.closedAt).getTime() - new Date(b.closedAt).getTime());
	let net = 0;
	let grossProfit = 0;
	let grossLoss = 0;
	let wins = 0;
	let losses = 0;
	let scratches = 0;
	let winSum = 0;
	let lossSum = 0;
	let rSum = 0;
	let rCount = 0;
	for (const t of sorted) {
		const pnl = tradePnl(t);
		net = moneyRound(net + pnl);
		if (pnl > 0) {
			wins += 1;
			winSum += pnl;
			grossProfit = moneyRound(grossProfit + pnl);
		} else if (pnl < 0) {
			losses += 1;
			lossSum += pnl;
			grossLoss = moneyRound(grossLoss + pnl);
		} else scratches += 1;
		const r = tradeR(t);
		if (r != null && Number.isFinite(r)) {
			rSum += r;
			rCount += 1;
		}
	}
	const decisive = wins + losses;
	const avgWin = wins ? moneyRound(winSum / wins) : null;
	const avgLoss = losses ? moneyRound(lossSum / losses) : null;
	const lossAbs = Math.abs(grossLoss);
	const curve = buildEquity(sorted, startingBalance);
	let peak = moneyRound(startingBalance);
	let maxDrawdown = 0;
	let maxDrawdownPct = 0;
	for (const point of curve) {
		peak = Math.max(peak, point.equity);
		const dd = moneyRound(peak - point.equity);
		if (dd > maxDrawdown) maxDrawdown = dd;
		if (peak > 0) maxDrawdownPct = Math.max(maxDrawdownPct, dd / peak);
	}
	let streak = {
		kind: "none",
		count: 0
	};
	for (let i = sorted.length - 1; i >= 0; i -= 1) {
		const pnl = tradePnl(sorted[i]);
		const kind = pnl > 0 ? "win" : pnl < 0 ? "loss" : null;
		if (!kind) continue;
		if (streak.kind === "none") streak = {
			kind,
			count: 1
		};
		else if (streak.kind === kind) streak = {
			kind,
			count: streak.count + 1
		};
		else break;
	}
	return {
		count: trades.length,
		wins,
		losses,
		scratches,
		net,
		grossProfit,
		grossLoss,
		winRate: decisive ? wins / decisive : null,
		profitFactor: lossAbs === 0 ? grossProfit > 0 ? Number.POSITIVE_INFINITY : null : grossProfit / lossAbs,
		expectancy: trades.length ? moneyRound(net / trades.length) : null,
		avgWin,
		avgLoss,
		avgR: rCount ? rSum / rCount : null,
		payoff: avgWin != null && avgLoss != null && avgLoss !== 0 ? avgWin / Math.abs(avgLoss) : null,
		maxDrawdown,
		maxDrawdownPct: curve.length ? maxDrawdownPct : null,
		streak,
		firstAt: sorted[0]?.closedAt ?? null,
		lastAt: sorted[sorted.length - 1]?.closedAt ?? null
	};
}
function groupTrades(trades, keyOf) {
	const map = /* @__PURE__ */ new Map();
	for (const t of trades) {
		const key = keyOf(t);
		const list = map.get(key);
		if (list) list.push(t);
		else map.set(key, [t]);
	}
	return [...map.entries()].map(([key, list]) => {
		let net = 0;
		let wins = 0;
		let decisive = 0;
		for (const t of list) {
			const pnl = tradePnl(t);
			net += pnl;
			if (pnl > 0) {
				wins += 1;
				decisive += 1;
			} else if (pnl < 0) decisive += 1;
		}
		return {
			key,
			net: moneyRound(net),
			count: list.length,
			wins,
			winRate: decisive ? wins / decisive : null
		};
	});
}
function planSplit(trades) {
	const groups = groupTrades(trades, (t) => t.followedPlan ? "on" : "off");
	const empty = (key) => ({
		key,
		net: 0,
		count: 0,
		wins: 0,
		winRate: null
	});
	return {
		on: groups.find((g) => g.key === "on") ?? empty("on"),
		off: groups.find((g) => g.key === "off") ?? empty("off")
	};
}
function matchesQuery(t, query) {
	if (query.day && dayKey(t.closedAt) !== query.day) return false;
	const pnl = tradePnl(t);
	if (query.result === "wins" && pnl <= 0) return false;
	if (query.result === "losses" && pnl >= 0) return false;
	if (query.result === "offplan" && t.followedPlan) return false;
	const q = query.q.trim().toLowerCase();
	if (!q) return true;
	return [
		t.symbol,
		t.setup,
		t.notes,
		t.market,
		t.side,
		...t.tags
	].join(" ").toLowerCase().includes(q);
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-xl font-medium tabular-nums tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-subtle",
				children: hint
			})
		]
	});
}
function streakCopy(kind, count) {
	if (kind === "none" || count === 0) return "No streak yet";
	if (count === 1) return kind === "win" ? "Last close was a winner" : "Last close was a loss";
	return kind === "win" ? `${count} winners in a row` : `${count} losses in a row`;
}
function Overview({ trades, rules, checks, startingBalance, onCreate, onEdit, onReviewRules }) {
	const stats = journalStats(trades, startingBalance);
	const equity = buildEquity(trades, startingBalance);
	const plan = planSplit(trades);
	const recent = [...trades].sort((a, b) => new Date(b.closedAt).getTime() - new Date(a.closedAt).getTime());
	const honored = (checks[todayKey()] ?? []).filter((id) => rules.some((rule) => rule.id === id)).length;
	if (trades.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium tracking-tight",
				children: "The book is empty"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-prose text-sm text-muted",
				children: "Log a closed trade, or load the sample book from settings to see how a review reads. Nothing is uploaded. It stays in this browser."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-5",
				onClick: onCreate,
				children: "Log a trade"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Closed P&L"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-2 font-mono text-4xl font-medium tabular-nums tracking-tight md:text-5xl ${pnlClass(stats.net)}`,
			children: formatMoney(stats.net)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted",
			children: [
				stats.count,
				" closed",
				stats.firstAt && stats.lastAt ? ` · ${formatDay(stats.firstAt)} – ${formatDay(stats.lastAt)}` : "",
				" · ",
				streakCopy(stats.streak.kind, stats.streak.count)
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Win rate",
					value: formatPct(stats.winRate),
					hint: stats.wins + stats.losses ? `${stats.wins} of ${stats.wins + stats.losses}` : "No decisive trades"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Profit factor",
					value: formatFactor(stats.profitFactor),
					hint: stats.payoff != null ? `Payoff ${stats.payoff.toFixed(2)}` : "Gross win / gross loss"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Expectancy",
					value: stats.expectancy == null ? "—" : formatMoney(stats.expectancy),
					hint: "Average trade"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Max drawdown",
					value: stats.maxDrawdown ? formatMoney(-stats.maxDrawdown) : formatMoney(0, false),
					hint: stats.maxDrawdownPct != null ? `${formatPct(stats.maxDrawdownPct)} of peak` : "From the equity peak"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquityChart, { points: equity })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 grid gap-3 lg:grid-cols-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onReviewRules,
				className: "rounded-xl border border-border bg-card p-4 text-left lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Today’s rules"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xl font-medium tabular-nums",
						children: [
							honored,
							" of ",
							rules.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-subtle",
						children: "Honored so far. Open the list."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:col-span-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "On plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-2 font-mono text-xl font-medium tabular-nums ${pnlClass(plan.on.net)}`,
							children: formatMoney(plan.on.net)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-subtle",
							children: [
								plan.on.count,
								" trades · ",
								formatPct(plan.on.winRate)
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Off plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-2 font-mono text-xl font-medium tabular-nums ${pnlClass(plan.off.net)}`,
							children: formatMoney(plan.off.net)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-subtle",
							children: [
								plan.off.count,
								" trades · ",
								formatPct(plan.off.winRate)
							]
						})
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium text-muted",
				children: "Recent closes"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border overflow-hidden rounded-xl border border-border",
				children: recent.slice(0, 6).map((trade) => {
					const pnl = tradePnl(trade);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onEdit(trade),
						className: "flex w-full items-center justify-between gap-3 bg-card px-4 py-3 text-left hover:bg-card-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-sm font-medium",
								children: [trade.symbol, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-normal text-muted",
									children: [" · ", sideLabel(trade.side)]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block truncate text-sm text-subtle",
								children: [
									formatDay(trade.closedAt),
									" · ",
									trade.setup || "No setup"
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `block font-mono text-sm tabular-nums ${pnlClass(pnl)}`,
								children: formatMoney(pnl)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block font-mono text-sm tabular-nums text-subtle",
								children: formatR(tradeR(trade))
							})]
						})]
					}) }, trade.id);
				})
			})]
		})
	] });
}
var WEEKDAYS = [
	"Mon",
	"Tue",
	"Wed",
	"Thu",
	"Fri",
	"Sat",
	"Sun"
];
var SESSIONS$1 = [
	"asia",
	"london",
	"newyork",
	"other"
];
var GRADES$1 = [
	"A",
	"B",
	"C",
	"F"
];
var SIDES$1 = ["long", "short"];
function Meter({ stat, max }) {
	const width = max === 0 ? 0 : Math.min(100, Math.abs(stat.net) / max * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "min-w-0 truncate text-sm",
				children: stat.key
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("font-mono text-sm tabular-nums", pnlClass(stat.net)),
				children: formatMoney(stat.net)
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-2 rounded-sm bg-card-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("h-2 rounded-sm", stat.net > 0 ? "bg-up" : stat.net < 0 ? "bg-down" : "bg-border"),
				style: { width: `${width}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-subtle",
			children: [
				stat.count,
				" trades · ",
				formatPct(stat.winRate)
			]
		})
	] });
}
function Panel({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-sm font-medium text-muted",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-4",
			children
		})]
	});
}
function ordered(stats, keys, label) {
	return keys.map((key) => {
		const found = stats.find((item) => item.key === key);
		return {
			key: label(key),
			net: found?.net ?? 0,
			count: found?.count ?? 0,
			winRate: found?.winRate ?? null
		};
	});
}
function ReviewView({ trades, onOpenDay }) {
	const scroller = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (el) el.scrollLeft = el.scrollWidth;
	}, [trades.length]);
	if (trades.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Log a few closes and the review fills in."
	});
	const plan = planSplit(trades);
	const setups = groupTrades(trades, (t) => t.setup || "No setup").sort((a, b) => b.net - a.net);
	const setupMax = Math.max(...setups.map((item) => Math.abs(item.net)), 0);
	const symbols = groupTrades(trades, (t) => t.symbol).sort((a, b) => Math.abs(b.net) - Math.abs(a.net));
	const symbolMax = Math.max(...symbols.slice(0, 6).map((item) => Math.abs(item.net)), 0);
	const weekdays = ordered(groupTrades(trades, (t) => format(new Date(t.closedAt), "EEE")), [...WEEKDAYS], (key) => key);
	const weekdayMax = Math.max(...weekdays.map((item) => Math.abs(item.net)), 0);
	const sessions = ordered(groupTrades(trades, (t) => t.session), SESSIONS$1, (key) => sessionLabel(key));
	const sessionMax = Math.max(...sessions.map((item) => Math.abs(item.net)), 0);
	const sides = ordered(groupTrades(trades, (t) => t.side), SIDES$1, (key) => sideLabel(key));
	const sideMax = Math.max(...sides.map((item) => Math.abs(item.net)), 0);
	const grades = ordered(groupTrades(trades, (t) => t.grade), GRADES$1, (key) => `Grade ${key}`);
	const gradeMax = Math.max(...grades.map((item) => Math.abs(item.net)), 0);
	const tags = groupTrades(trades.filter((t) => t.tags.length), (t) => t.tags[0] ?? "").sort((a, b) => a.net - b.net);
	const tagMax = Math.max(...tags.map((item) => Math.abs(item.net)), 0);
	const byDay = /* @__PURE__ */ new Map();
	for (const trade of trades) {
		const key = dayKey(trade.closedAt);
		byDay.set(key, (byDay.get(key) ?? 0) + tradePnl(trade));
	}
	const today = /* @__PURE__ */ new Date();
	today.setHours(12, 0, 0, 0);
	const mondayOffset = (today.getDay() + 6) % 7;
	const thisMonday = new Date(today);
	thisMonday.setDate(today.getDate() - mondayOffset);
	const weeks = 13;
	const start = new Date(thisMonday);
	start.setDate(start.getDate() - 84);
	const todayId = todayKey();
	const columns = [];
	for (let w = 0; w < weeks; w += 1) {
		const days = [];
		for (let d = 0; d < 7; d += 1) {
			const date = new Date(start);
			date.setDate(start.getDate() + w * 7 + d);
			const key = format(date, "yyyy-MM-dd");
			const future = key > todayId;
			days.push({
				key,
				pnl: future ? null : byDay.get(key) ?? null,
				future,
				label: format(date, "EEE MMM d")
			});
		}
		columns.push(days);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "min-w-0 rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-muted",
							children: "Daily result"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							ref: scroller,
							className: "mt-4 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex w-max gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-col gap-1 pr-1",
									children: [
										"M",
										"T",
										"W",
										"T",
										"F",
										"S",
										"S"
									].map((label, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex h-11 w-4 items-center text-xs text-subtle",
										children: label
									}, `${label}-${index}`))
								}), columns.map((week) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-col gap-1",
									children: week.map((day) => {
										const traded = day.pnl != null && byDay.has(day.key);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: day.future || !traded,
											onClick: () => onOpenDay(day.key),
											"aria-label": day.future ? `${day.label}, ahead` : traded ? `${day.label}, ${formatMoney(day.pnl ?? 0)}` : `${day.label}, no trades`,
											className: cn("size-11 rounded-sm", day.future && "border border-border bg-transparent", !day.future && !traded && "bg-card-2", traded && (day.pnl ?? 0) > 0 && "bg-up", traded && (day.pnl ?? 0) < 0 && "bg-down", traded && day.pnl === 0 && "bg-border", day.key === todayId && "ring-2 ring-accent")
										}, day.key);
									})
								}, week[0].key))]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-subtle",
							children: "Last 13 weeks. A filled day opens that book."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-muted",
							children: "Plan"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Followed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mt-1 font-mono text-2xl font-medium tabular-nums", pnlClass(plan.on.net)),
									children: formatMoney(plan.on.net)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-subtle",
									children: [
										plan.on.count,
										" trades · ",
										formatPct(plan.on.winRate),
										" wins"
									]
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Broke"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("mt-1 font-mono text-2xl font-medium tabular-nums", pnlClass(plan.off.net)),
									children: formatMoney(plan.off.net)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-subtle",
									children: [
										plan.off.count,
										" trades · ",
										formatPct(plan.off.winRate),
										" wins"
									]
								})
							] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "The gap is the cost of trading a plan you did not actually use."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "By setup",
				children: setups.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
					stat,
					max: setupMax
				}, stat.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "By symbol",
				children: symbols.slice(0, 6).map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
					stat,
					max: symbolMax
				}, stat.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Weekday",
						children: weekdays.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							stat,
							max: weekdayMax
						}, stat.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Session",
						children: sessions.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							stat,
							max: sessionMax
						}, stat.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Side",
						children: sides.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							stat,
							max: sideMax
						}, stat.key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
						title: "Grade",
						children: grades.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
							stat,
							max: gradeMax
						}, stat.key))
					})
				]
			}),
			tags.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
				title: "Tagged leaks",
				children: tags.map((stat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
					stat,
					max: tagMax
				}, stat.key))
			}) : null
		]
	});
}
function RulesView({ rules, checks, onToggle, onAdd, onUpdate, onDelete }) {
	const [draft, setDraft] = (0, import_react.useState)("");
	const today = todayKey();
	const done = new Set(checks[today] ?? []);
	const honored = rules.filter((rule) => done.has(rule.id)).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: format(/* @__PURE__ */ new Date(), "EEEE, MMM d")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 font-mono text-3xl font-medium tabular-nums tracking-tight",
				children: [
					honored,
					" of ",
					rules.length
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Check a rule after the session, not when you want it to be true."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 divide-y divide-border overflow-hidden rounded-xl border border-border",
				children: rules.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "bg-card px-4 py-4 text-sm text-muted",
					children: "No rules yet. Add the ones you actually break."
				}) : rules.map((rule) => {
					const checked = done.has(rule.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3 bg-card px-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked,
								onChange: () => onToggle(today, rule.id),
								"aria-label": `Honored: ${rule.text}`,
								className: "mt-3 size-4 accent-accent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: rule.text,
								onChange: (event) => onUpdate(rule.id, event.target.value),
								onBlur: (event) => {
									const next = event.target.value.trim();
									if (!next) onDelete(rule.id);
									else if (next !== rule.text) onUpdate(rule.id, next);
								},
								className: "mt-1 min-h-11 w-full bg-transparent text-sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onDelete(rule.id),
								"aria-label": "Delete rule",
								className: "press inline-flex size-11 shrink-0 items-center justify-center rounded-sm text-muted hover:bg-card-2 hover:text-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					}, rule.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 flex flex-col gap-2 sm:flex-row",
				onSubmit: (event) => {
					event.preventDefault();
					const text = draft.trim();
					if (!text || rules.length >= 12) return;
					onAdd(text);
					setDraft("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: draft,
					onChange: (event) => setDraft(event.target.value),
					placeholder: "Add a rule",
					"aria-label": "New rule",
					maxLength: 180,
					className: "h-11 w-full rounded-sm border border-border bg-card px-3 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "secondary",
					disabled: !draft.trim() || rules.length >= 12,
					children: "Add"
				})]
			})
		]
	});
}
function Modal({ open, onOpenChange, title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "folio-overlay fixed inset-0 z-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "folio-dialog rounded-xl border border-border bg-card p-4 shadow-none",
			"aria-describedby": description ? "folio-dialog-desc" : void 0,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "text-lg font-medium tracking-tight",
					children: title
				}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					id: "folio-dialog-desc",
					className: "mt-1 text-sm text-muted",
					children: description
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "sr-only",
					children: title
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "inline-flex size-11 items-center justify-center rounded-sm text-muted hover:bg-card-2 hover:text-foreground",
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: cn("min-w-0"),
				children
			})]
		})] })
	});
}
var control = "h-11 w-full rounded-sm border border-border bg-background px-3 text-sm text-foreground";
function TextField({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(control, className),
		...props
	});
}
function AreaField({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(control, "h-auto min-h-24 resize-y py-3 leading-normal", className),
		...props
	});
}
function SelectField({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(control, className),
		...props
	});
}
function FieldLabel({ children, htmlFor }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor,
		className: "mb-1.5 block text-sm font-medium text-muted",
		children
	});
}
var MARKETS = [
	"stocks",
	"options",
	"futures",
	"forex",
	"crypto"
];
var SIDES = ["long", "short"];
var SESSIONS = [
	"asia",
	"london",
	"newyork",
	"other"
];
var GRADES = [
	"A",
	"B",
	"C",
	"F"
];
var tradeSchema = object({
	id: string().min(1),
	symbol: string().min(1),
	market: _enum(MARKETS),
	side: _enum(SIDES),
	openedAt: string().min(1),
	closedAt: string().min(1),
	entry: number().finite(),
	exit: number().finite(),
	quantity: number().positive().finite(),
	stop: number().finite().nullable(),
	fees: number().nonnegative().finite(),
	setup: string(),
	session: _enum(SESSIONS),
	grade: _enum(GRADES),
	followedPlan: boolean(),
	notes: string(),
	tags: array(string())
});
var backupSchema = object({
	version: literal(1),
	startingBalance: number().nonnegative().finite(),
	trades: array(tradeSchema),
	rules: array(object({
		id: string().min(1),
		text: string().min(1)
	})),
	checks: record(string(), array(string())),
	sampleBanner: boolean()
});
function serializeBackup(data) {
	return JSON.stringify(data, null, 2);
}
function parseBackup(raw) {
	let json;
	try {
		json = JSON.parse(raw);
	} catch {
		return { ok: false };
	}
	const parsed = backupSchema.safeParse(json);
	if (!parsed.success) return { ok: false };
	return {
		ok: true,
		data: parsed.data
	};
}
function SettingsDialog({ open, onOpenChange, startingBalance, backup, onBalance, onReplace, onClear, onSample }) {
	const fileRef = (0, import_react.useRef)(null);
	const [balance, setBalance] = (0, import_react.useState)(String(startingBalance));
	const [error, setError] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("idle");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setBalance(String(startingBalance));
		setError(null);
		setPending(null);
		setMode("idle");
	}, [open, startingBalance]);
	function close(next) {
		if (!next) {
			setError(null);
			setPending(null);
			setMode("idle");
			setBalance(String(startingBalance));
		}
		onOpenChange(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: close,
		title: "Settings",
		description: "Stored in this browser only. Download a backup if you want a copy.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5",
			children: [
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-down",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-2",
					onSubmit: (event) => {
						event.preventDefault();
						const value = Number(balance);
						if (!Number.isFinite(value) || value < 0) {
							setError("Starting balance has to be zero or more.");
							return;
						}
						setError(null);
						onBalance(value);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "balance",
							children: "Starting balance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								id: "balance",
								inputMode: "decimal",
								value: balance,
								onChange: (event) => setBalance(event.target.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "secondary",
								children: "Save"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-subtle",
							children: "Used for the equity curve and drawdown."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => {
								const blob = new Blob([serializeBackup(backup)], { type: "application/json" });
								const url = URL.createObjectURL(blob);
								const link = document.createElement("a");
								link.href = url;
								link.download = `folio-${format(/* @__PURE__ */ new Date(), "yyyy-MM-dd")}.json`;
								link.click();
								URL.revokeObjectURL(url);
							},
							children: "Download backup"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => fileRef.current?.click(),
							children: "Restore backup"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json,.json",
							className: "sr-only",
							onChange: async (event) => {
								const file = event.target.files?.[0];
								event.target.value = "";
								if (!file) return;
								const parsed = parseBackup(await file.text());
								if (!parsed.ok) {
									setError("That file isn’t a Folio backup.");
									setPending(null);
									return;
								}
								setError(null);
								setPending(parsed.data);
								setMode("idle");
							}
						})
					]
				}),
				pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-sm border border-border bg-background p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Replace this journal with ",
							pending.trades.length,
							" trades from the file?"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								onReplace(pending);
								setPending(null);
								close(false);
							},
							children: "Replace"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setPending(null),
							children: "Cancel"
						})]
					})]
				}) : null,
				mode === "clear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-sm border border-border bg-background p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Erase every trade? Rules and the starting balance stay."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								onClear();
								setMode("idle");
								close(false);
							},
							children: "Erase trades"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setMode("idle"),
							children: "Keep"
						})]
					})]
				}) : mode === "sample" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-sm border border-border bg-background p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Replace trades, rules, and balance with the sample book?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								onSample();
								setMode("idle");
								close(false);
							},
							children: "Load sample"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setMode("idle"),
							children: "Keep mine"
						})]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: () => setMode("sample"),
						children: "Load sample book"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => setMode("clear"),
						children: "Erase trades"
					})]
				})
			]
		})
	});
}
function blankDraft() {
	const now = nowLocalInput();
	return {
		symbol: "",
		market: "stocks",
		side: "long",
		openedAt: now,
		closedAt: now,
		entry: "",
		exit: "",
		quantity: "",
		stop: "",
		fees: "0",
		setup: "",
		session: "newyork",
		grade: "B",
		followedPlan: true,
		notes: "",
		tags: ""
	};
}
function fromTrade(trade) {
	return {
		symbol: trade.symbol,
		market: trade.market,
		side: trade.side,
		openedAt: toDatetimeLocal(trade.openedAt),
		closedAt: toDatetimeLocal(trade.closedAt),
		entry: String(trade.entry),
		exit: String(trade.exit),
		quantity: String(trade.quantity),
		stop: trade.stop == null ? "" : String(trade.stop),
		fees: String(trade.fees),
		setup: trade.setup,
		session: trade.session,
		grade: trade.grade,
		followedPlan: trade.followedPlan,
		notes: trade.notes,
		tags: trade.tags.join(", ")
	};
}
function num(value) {
	const trimmed = value.trim();
	if (!trimmed) return null;
	const n = Number(trimmed);
	return Number.isFinite(n) ? n : null;
}
function Choice({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-1.5 text-sm font-medium text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "radiogroup",
		"aria-label": label,
		className: "flex flex-wrap gap-2",
		children: options.map((option) => {
			const active = option.value === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "radio",
				"aria-checked": active,
				onClick: () => onChange(option.value),
				className: cn("press h-11 rounded-sm px-3 text-sm", active ? "bg-accent text-accent-foreground" : "border border-border bg-background text-muted"),
				children: option.label
			}, option.value);
		})
	})] });
}
function TradeDialog({ open, trade, setups, onOpenChange, onSave, onDelete }) {
	const [draft, setDraft] = (0, import_react.useState)(blankDraft);
	const [error, setError] = (0, import_react.useState)(null);
	const [confirmDelete, setConfirmDelete] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setDraft(trade ? fromTrade(trade) : blankDraft());
		setError(null);
		setConfirmDelete(false);
	}, [open, trade]);
	const preview = (0, import_react.useMemo)(() => {
		const entry = num(draft.entry);
		const exit = num(draft.exit);
		const quantity = num(draft.quantity);
		const fees = num(draft.fees) ?? 0;
		const stop = draft.stop.trim() ? num(draft.stop) : null;
		if (entry == null || exit == null || quantity == null || quantity <= 0 || draft.stop.trim() !== "" && stop == null) return null;
		const core = {
			side: draft.side,
			entry,
			exit,
			quantity,
			fees,
			stop
		};
		return {
			pnl: tradePnl(core),
			r: tradeR(core)
		};
	}, [draft]);
	function set(key, value) {
		setDraft((current) => ({
			...current,
			[key]: value
		}));
	}
	function save() {
		const symbol = draft.symbol.trim().toUpperCase();
		const entry = num(draft.entry);
		const exit = num(draft.exit);
		const quantity = num(draft.quantity);
		const fees = num(draft.fees) ?? 0;
		const stop = draft.stop.trim() ? num(draft.stop) : null;
		const openedAt = fromDatetimeLocal(draft.openedAt);
		const closedAt = fromDatetimeLocal(draft.closedAt);
		if (!symbol || entry == null || exit == null || quantity == null || quantity <= 0) {
			setError("Symbol, entry, exit, and size are required.");
			return;
		}
		if (draft.stop.trim() && stop == null) {
			setError("Stop has to be a number, or left blank.");
			return;
		}
		if (fees < 0 || !Number.isFinite(fees)) {
			setError("Fees can’t be negative.");
			return;
		}
		if (!openedAt || !closedAt) {
			setError("Open and close need a valid date.");
			return;
		}
		if (new Date(closedAt).getTime() < new Date(openedAt).getTime()) {
			setError("Close is before the open.");
			return;
		}
		const tags = [...new Set(draft.tags.split(",").map((tag) => tag.trim().toLowerCase()).filter(Boolean))].slice(0, 6);
		onSave({
			id: trade?.id ?? crypto.randomUUID(),
			symbol,
			market: draft.market,
			side: draft.side,
			openedAt,
			closedAt,
			entry,
			exit,
			quantity,
			stop,
			fees,
			setup: draft.setup.trim(),
			session: draft.session,
			grade: draft.grade,
			followedPlan: draft.followedPlan,
			notes: draft.notes.trim(),
			tags
		});
		onOpenChange(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange,
		title: trade ? trade.symbol : "Log a trade",
		description: "Closed trades only. Size is shares, units, or dollars per point — one ES contract is 50.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-down",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "symbol",
						children: "Symbol"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
						id: "symbol",
						value: draft.symbol,
						onChange: (event) => set("symbol", event.target.value),
						autoComplete: "off",
						placeholder: "NVDA"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "market",
						children: "Market"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
						id: "market",
						value: draft.market,
						onChange: (event) => set("market", event.target.value),
						children: MARKETS.map((market) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: market,
							children: marketLabel(market)
						}, market))
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Side",
					value: draft.side,
					onChange: (side) => set("side", side),
					options: [{
						value: "long",
						label: sideLabel("long")
					}, {
						value: "short",
						label: sideLabel("short")
					}]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "opened",
							children: "Opened"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "opened",
							type: "datetime-local",
							value: draft.openedAt,
							onChange: (event) => set("openedAt", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "closed",
							children: "Closed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "closed",
							type: "datetime-local",
							value: draft.closedAt,
							onChange: (event) => set("closedAt", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "entry",
							children: "Entry"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "entry",
							inputMode: "decimal",
							value: draft.entry,
							onChange: (event) => set("entry", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "exit",
							children: "Exit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "exit",
							inputMode: "decimal",
							value: draft.exit,
							onChange: (event) => set("exit", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "size",
							children: "Size"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "size",
							inputMode: "decimal",
							value: draft.quantity,
							onChange: (event) => set("quantity", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "stop",
							children: "Stop"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "stop",
							inputMode: "decimal",
							value: draft.stop,
							placeholder: "Optional, for R",
							onChange: (event) => set("stop", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "fees",
							children: "Fees"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
							id: "fees",
							inputMode: "decimal",
							value: draft.fees,
							onChange: (event) => set("fees", event.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "setup",
								children: "Setup"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
								id: "setup",
								value: draft.setup,
								list: "folio-setups",
								onChange: (event) => set("setup", event.target.value),
								placeholder: "Pullback"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "folio-setups",
								children: [.../* @__PURE__ */ new Set([
									"Pullback",
									"Breakout",
									"Opening drive",
									"Mean revert",
									"Reversal",
									...setups
								])].map((setup) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: setup }, setup))
							})
						] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Session",
					value: draft.session,
					onChange: (session) => set("session", session),
					options: SESSIONS.map((session) => ({
						value: session,
						label: sessionLabel(session)
					}))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Grade",
					value: draft.grade,
					onChange: (grade) => set("grade", grade),
					options: GRADES.map((grade) => ({
						value: grade,
						label: grade
					}))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
					label: "Followed the plan",
					value: draft.followedPlan ? "yes" : "no",
					onChange: (value) => set("followedPlan", value === "yes"),
					options: [{
						value: "yes",
						label: "Yes"
					}, {
						value: "no",
						label: "No"
					}]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "tags",
					children: "Tags"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
					id: "tags",
					value: draft.tags,
					onChange: (event) => set("tags", event.target.value),
					placeholder: "oversize, late entry"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "notes",
					children: "Lesson"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaField, {
					id: "notes",
					value: draft.notes,
					maxLength: 2e3,
					onChange: (event) => set("notes", event.target.value),
					placeholder: "What you will do the same, or not."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-sm border border-border bg-background px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Result"
					}), preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("mt-1 font-mono text-xl font-medium tabular-nums", pnlClass(preview.pnl)),
						children: [formatMoney(preview.pnl), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-3 text-base text-muted",
							children: formatR(preview.r)
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-subtle",
						children: "Enter prices and size to preview P&L."
					})]
				}),
				confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:justify-end",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted sm:mr-auto sm:self-center",
							children: "Erase this trade? It cannot be undone."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => setConfirmDelete(false),
							children: "Keep"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: () => {
								if (trade) onDelete(trade.id);
								onOpenChange(false);
							},
							children: "Erase"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:justify-end",
					children: [
						trade ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							className: "sm:mr-auto",
							onClick: () => setConfirmDelete(true),
							children: "Delete"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							onClick: () => onOpenChange(false),
							children: "Cancel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Save trade"
						})
					]
				})
			]
		})
	});
}
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "wins",
		label: "Wins"
	},
	{
		id: "losses",
		label: "Losses"
	},
	{
		id: "offplan",
		label: "Off plan"
	}
];
function Chip({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": active,
		onClick,
		className: cn("press h-11 shrink-0 rounded-sm px-3 text-sm", active ? "bg-accent text-accent-foreground" : "border border-border bg-card text-muted"),
		children
	});
}
function TradesView({ trades, query, onQuery, onEdit }) {
	const visible = [...trades].sort((a, b) => new Date(b.closedAt).getTime() - new Date(a.closedAt).getTime()).filter((trade) => matchesQuery(trade, query));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query.q,
				onChange: (event) => onQuery({
					...query,
					q: event.target.value
				}),
				placeholder: "Search symbol, setup, notes",
				"aria-label": "Search trades",
				className: "h-11 w-full rounded-sm border border-border bg-card px-3 text-sm sm:max-w-xs"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: FILTERS.map((filter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: query.result === filter.id,
					onClick: () => onQuery({
						...query,
						result: filter.id
					}),
					children: filter.label
				}, filter.id))
			})]
		}),
		query.day ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				active: true,
				onClick: () => onQuery({
					...query,
					day: null
				}),
				children: `${format(parseISO(query.day), "MMM d")} · clear`
			})
		}) : null,
		visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 text-sm text-muted",
			children: "No trades match."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-border overflow-hidden rounded-xl border border-border lg:hidden",
			children: visible.map((trade) => {
				const pnl = tradePnl(trade);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onEdit(trade),
					className: "flex w-full items-start justify-between gap-3 bg-card px-4 py-3 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm font-medium",
								children: trade.symbol
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block text-sm text-muted",
								children: [
									sideLabel(trade.side),
									" · ",
									trade.setup || "No setup",
									" · ",
									trade.grade
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-1 block text-sm text-subtle",
								children: [
									formatDay(trade.closedAt),
									" · ",
									sessionLabel(trade.session)
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `block font-mono text-sm tabular-nums ${pnlClass(pnl)}`,
							children: formatMoney(pnl)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-mono text-sm tabular-nums text-subtle",
							children: formatR(tradeR(trade))
						})]
					})]
				}) }, trade.id);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 hidden overflow-hidden rounded-xl border border-border lg:block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "trade-grid border-b border-border px-4 py-3 text-sm text-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Date" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Symbol" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Side" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Setup" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: "P&L"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: "R"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: visible.map((trade) => {
				const pnl = tradePnl(trade);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-border last:border-b-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onEdit(trade),
						className: "trade-grid w-full bg-card px-4 py-3 text-left text-sm hover:bg-card-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: formatDay(trade.closedAt)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: trade.symbol
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-subtle",
								children: [
									formatPrice(trade.entry),
									" → ",
									formatPrice(trade.exit),
									" · ",
									formatQty(trade.quantity)
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: sideLabel(trade.side)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "truncate",
								children: [trade.setup || "No setup", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-subtle",
									children: [" · ", marketLabel(trade.market)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-right font-mono tabular-nums ${pnlClass(pnl)}`,
								children: formatMoney(pnl)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right font-mono tabular-nums text-muted",
								children: formatR(tradeR(trade))
							})
						]
					})
				}, trade.id);
			}) })]
		})] })
	] });
}
function iso(daysAgo, hour, minute = 0) {
	const d = /* @__PURE__ */ new Date();
	d.setDate(d.getDate() - daysAgo);
	d.setHours(hour, minute, 0, 0);
	return d.toISOString();
}
function dayTrade(partial) {
	const { daysAgo, openHour, closeHour, ...rest } = partial;
	return {
		...rest,
		openedAt: iso(daysAgo, openHour, 32),
		closedAt: iso(daysAgo, closeHour, 8)
	};
}
var SAMPLE_RULES = [
	{
		id: "r1",
		text: "Risk is defined before the order, and it is at most 1R."
	},
	{
		id: "r2",
		text: "No trade in the first five minutes unless it was planned."
	},
	{
		id: "r3",
		text: "Two losses and the session is finished."
	},
	{
		id: "r4",
		text: "Size comes from the stop, never from how sure it feels."
	},
	{
		id: "r5",
		text: "Write the lesson before the next order."
	}
];
function buildSample() {
	return {
		trades: [
			dayTrade({
				id: "t-aapl-1",
				daysAgo: 38,
				openHour: 10,
				closeHour: 15,
				symbol: "AAPL",
				market: "stocks",
				side: "long",
				entry: 226.4,
				exit: 231.15,
				quantity: 50,
				stop: 223.8,
				fees: 1.2,
				setup: "Pullback",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "First pullback to the opening range high. Sold into the prior day high.",
				tags: []
			}),
			dayTrade({
				id: "t-es-1",
				daysAgo: 36,
				openHour: 10,
				closeHour: 11,
				symbol: "ES",
				market: "futures",
				side: "short",
				entry: 5742,
				exit: 5768,
				quantity: 50,
				stop: 5754,
				fees: 4.2,
				setup: "Opening drive",
				session: "newyork",
				grade: "C",
				followedPlan: false,
				notes: "Drive failed and I held through the stop. The idea was fine. The exit was not.",
				tags: ["held loser"]
			}),
			dayTrade({
				id: "t-nvda-1",
				daysAgo: 34,
				openHour: 11,
				closeHour: 15,
				symbol: "NVDA",
				market: "stocks",
				side: "long",
				entry: 131.2,
				exit: 136.8,
				quantity: 30,
				stop: 128.4,
				fees: 1.5,
				setup: "Breakout",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "Broke the morning shelf and held to the measured move. Did not add.",
				tags: []
			}),
			dayTrade({
				id: "t-eur-1",
				daysAgo: 31,
				openHour: 4,
				closeHour: 8,
				symbol: "EURUSD",
				market: "forex",
				side: "long",
				entry: 1.172,
				exit: 1.1768,
				quantity: 1e5,
				stop: 1.1695,
				fees: 7,
				setup: "Pullback",
				session: "london",
				grade: "A",
				followedPlan: true,
				notes: "London pullback into yesterday’s value. Target was the Asia high.",
				tags: []
			}),
			dayTrade({
				id: "t-btc-1",
				daysAgo: 29,
				openHour: 21,
				closeHour: 23,
				symbol: "BTC",
				market: "crypto",
				side: "long",
				entry: 63200,
				exit: 61840,
				quantity: .15,
				stop: 62400,
				fees: 8,
				setup: "Breakout",
				session: "asia",
				grade: "B",
				followedPlan: true,
				notes: "Breakout failed. Stopped where I said I would. No second try.",
				tags: []
			}),
			dayTrade({
				id: "t-amd",
				daysAgo: 27,
				openHour: 10,
				closeHour: 14,
				symbol: "AMD",
				market: "stocks",
				side: "long",
				entry: 164.5,
				exit: 171.2,
				quantity: 40,
				stop: 160,
				fees: 1.3,
				setup: "Pullback",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "Higher low against the open. Trailed once it cleared the morning high.",
				tags: []
			}),
			dayTrade({
				id: "t-es-2",
				daysAgo: 24,
				openHour: 10,
				closeHour: 13,
				symbol: "ES",
				market: "futures",
				side: "long",
				entry: 5810,
				exit: 5842,
				quantity: 50,
				stop: 5796,
				fees: 4.2,
				setup: "Opening drive",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "One contract. Took the planned scale at 2R and left the rest.",
				tags: []
			}),
			dayTrade({
				id: "t-gbp",
				daysAgo: 22,
				openHour: 3,
				closeHour: 7,
				symbol: "GBPUSD",
				market: "forex",
				side: "short",
				entry: 1.341,
				exit: 1.3362,
				quantity: 8e4,
				stop: 1.344,
				fees: 6,
				setup: "Mean revert",
				session: "london",
				grade: "B",
				followedPlan: true,
				notes: "Fade of the Asia extension. Covered into the session open price.",
				tags: []
			}),
			dayTrade({
				id: "t-tsla",
				daysAgo: 20,
				openHour: 14,
				closeHour: 15,
				symbol: "TSLA",
				market: "stocks",
				side: "long",
				entry: 248,
				exit: 241.5,
				quantity: 20,
				stop: 244,
				fees: 1.1,
				setup: "Breakout",
				session: "newyork",
				grade: "C",
				followedPlan: false,
				notes: "Chased a late breakout that was already extended. Stop was ignored for a minute too long.",
				tags: ["late entry"]
			}),
			dayTrade({
				id: "t-nvda-2",
				daysAgo: 18,
				openHour: 11,
				closeHour: 13,
				symbol: "NVDA",
				market: "stocks",
				side: "short",
				entry: 142.6,
				exit: 138.9,
				quantity: 25,
				stop: 145.2,
				fees: 1.4,
				setup: "Reversal",
				session: "newyork",
				grade: "B",
				followedPlan: false,
				notes: "Not on the list. Got paid. Still a leak if I start trusting leftovers.",
				tags: ["unplanned"]
			}),
			dayTrade({
				id: "t-nq",
				daysAgo: 16,
				openHour: 10,
				closeHour: 11,
				symbol: "NQ",
				market: "futures",
				side: "long",
				entry: 21450,
				exit: 21280,
				quantity: 20,
				stop: 21390,
				fees: 4.5,
				setup: "Opening drive",
				session: "newyork",
				grade: "F",
				followedPlan: false,
				notes: "Doubled size after the ES winner. The stop was right. The size was not.",
				tags: ["oversize"]
			}),
			dayTrade({
				id: "t-cl",
				daysAgo: 15,
				openHour: 10,
				closeHour: 14,
				symbol: "CL",
				market: "futures",
				side: "long",
				entry: 71.4,
				exit: 73.15,
				quantity: 1e3,
				stop: 70.6,
				fees: 5,
				setup: "Breakout",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "Inventory report held above the break. One contract, full target.",
				tags: []
			}),
			dayTrade({
				id: "t-aapl-2",
				daysAgo: 13,
				openHour: 11,
				closeHour: 12,
				symbol: "AAPL",
				market: "stocks",
				side: "short",
				entry: 234.2,
				exit: 236.8,
				quantity: 40,
				stop: 236,
				fees: 1,
				setup: "Mean revert",
				session: "newyork",
				grade: "B",
				followedPlan: true,
				notes: "Fade didn’t bite. Out just through the stop. Left it alone.",
				tags: []
			}),
			dayTrade({
				id: "t-es-3",
				daysAgo: 10,
				openHour: 10,
				closeHour: 15,
				symbol: "ES",
				market: "futures",
				side: "short",
				entry: 5920,
				exit: 5894,
				quantity: 50,
				stop: 5932,
				fees: 4.2,
				setup: "Pullback",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "Pullback into the open after a failed high. Held for the morning low.",
				tags: []
			}),
			dayTrade({
				id: "t-meta",
				daysAgo: 8,
				openHour: 10,
				closeHour: 15,
				symbol: "META",
				market: "stocks",
				side: "long",
				entry: 582,
				exit: 591.4,
				quantity: 15,
				stop: 574,
				fees: 1.2,
				setup: "Pullback",
				session: "newyork",
				grade: "B",
				followedPlan: true,
				notes: "Slow. Almost scratched it. The level held, so I let the target work.",
				tags: []
			}),
			dayTrade({
				id: "t-eur-2",
				daysAgo: 6,
				openHour: 4,
				closeHour: 6,
				symbol: "EURUSD",
				market: "forex",
				side: "short",
				entry: 1.1688,
				exit: 1.1712,
				quantity: 1e5,
				stop: 1.1705,
				fees: 7,
				setup: "News fade",
				session: "london",
				grade: "B",
				followedPlan: true,
				notes: "Fade was early. Slippage through the stop. Session ended there.",
				tags: []
			}),
			dayTrade({
				id: "t-nvda-3",
				daysAgo: 4,
				openHour: 11,
				closeHour: 15,
				symbol: "NVDA",
				market: "stocks",
				side: "long",
				entry: 139.1,
				exit: 144.6,
				quantity: 35,
				stop: 136.4,
				fees: 1.5,
				setup: "Pullback",
				session: "newyork",
				grade: "A",
				followedPlan: true,
				notes: "Same setup as the last long. Did not increase size to ‘make it back’.",
				tags: []
			}),
			dayTrade({
				id: "t-btc-2",
				daysAgo: 2,
				openHour: 20,
				closeHour: 23,
				symbol: "BTC",
				market: "crypto",
				side: "short",
				entry: 67450,
				exit: 66120,
				quantity: .2,
				stop: 68200,
				fees: 9,
				setup: "Reversal",
				session: "asia",
				grade: "A",
				followedPlan: true,
				notes: "Failed break of the day high. Covered into the prior shelf.",
				tags: []
			}),
			dayTrade({
				id: "t-es-4",
				daysAgo: 1,
				openHour: 10,
				closeHour: 11,
				symbol: "ES",
				market: "futures",
				side: "long",
				entry: 5988,
				exit: 5972,
				quantity: 50,
				stop: 5976,
				fees: 4.2,
				setup: "Opening drive",
				session: "newyork",
				grade: "B",
				followedPlan: true,
				notes: "Drive reversed. Out near the stop. Did not flip short.",
				tags: []
			})
		],
		rules: SAMPLE_RULES.map((rule) => ({ ...rule }))
	};
}
var useJournal = create()(persist((set) => ({
	trades: [],
	rules: [],
	checks: {},
	startingBalance: 25e3,
	initialized: false,
	sampleBanner: false,
	addTrade: (trade) => set((s) => ({
		trades: [trade, ...s.trades],
		sampleBanner: false
	})),
	updateTrade: (trade) => set((s) => ({
		trades: s.trades.map((item) => item.id === trade.id ? trade : item),
		sampleBanner: false
	})),
	deleteTrade: (id) => set((s) => ({
		trades: s.trades.filter((item) => item.id !== id),
		sampleBanner: false
	})),
	addRule: (text) => set((s) => ({
		rules: [...s.rules, {
			id: crypto.randomUUID(),
			text: text.trim()
		}],
		sampleBanner: false
	})),
	updateRule: (id, text) => set((s) => ({
		rules: s.rules.map((rule) => rule.id === id ? {
			...rule,
			text
		} : rule),
		sampleBanner: false
	})),
	deleteRule: (id) => set((s) => ({
		rules: s.rules.filter((rule) => rule.id !== id),
		checks: Object.fromEntries(Object.entries(s.checks).map(([date, ids]) => [date, ids.filter((ruleId) => ruleId !== id)])),
		sampleBanner: false
	})),
	toggleCheck: (date, ruleId) => set((s) => {
		const current = s.checks[date] ?? [];
		const next = current.includes(ruleId) ? current.filter((id) => id !== ruleId) : [...current, ruleId];
		return {
			checks: {
				...s.checks,
				[date]: next
			},
			sampleBanner: false
		};
	}),
	setStartingBalance: (value) => set({
		startingBalance: value,
		sampleBanner: false
	}),
	loadSample: () => {
		const sample = buildSample();
		set({
			trades: sample.trades,
			rules: sample.rules,
			checks: {},
			startingBalance: 25e3,
			initialized: true,
			sampleBanner: true
		});
	},
	clearTrades: () => set({
		trades: [],
		checks: {},
		sampleBanner: false,
		initialized: true
	}),
	dismissSample: () => set({ sampleBanner: false }),
	replaceAll: (data) => set({
		trades: data.trades,
		rules: data.rules,
		checks: data.checks,
		startingBalance: data.startingBalance,
		sampleBanner: false,
		initialized: true
	})
}), {
	name: "folio-journal-v1",
	skipHydration: true,
	storage: createJSONStorage(() => localStorage),
	partialize: (s) => ({
		trades: s.trades,
		rules: s.rules,
		checks: s.checks,
		startingBalance: s.startingBalance,
		initialized: s.initialized,
		sampleBanner: s.sampleBanner
	})
}));
function useHydrateJournal() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const finish = () => {
			if (cancel) return;
			if (!useJournal.getState().initialized) useJournal.getState().loadSample();
			setReady(true);
		};
		if (useJournal.persist.hasHydrated()) {
			finish();
			return () => {
				cancel = true;
			};
		}
		const unsub = useJournal.persist.onFinishHydration(finish);
		useJournal.persist.rehydrate();
		return () => {
			cancel = true;
			unsub();
		};
	}, []);
	return ready;
}
var NAV = [
	{
		id: "overview",
		label: "Overview",
		icon: LayoutDashboard
	},
	{
		id: "trades",
		label: "Trades",
		icon: List
	},
	{
		id: "review",
		label: "Review",
		icon: SquareChartGantt
	},
	{
		id: "rules",
		label: "Rules",
		icon: BookOpen
	}
];
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-8 shrink-0",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "8",
			className: "fill-accent"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9 8h14v3.2H13.2V14.6h8.3v3.2h-8.3V24H9V8z",
			className: "fill-accent-foreground"
		})]
	});
}
function JournalApp() {
	const ready = useHydrateJournal();
	const trades = useJournal((s) => s.trades);
	const rules = useJournal((s) => s.rules);
	const checks = useJournal((s) => s.checks);
	const startingBalance = useJournal((s) => s.startingBalance);
	const sampleBanner = useJournal((s) => s.sampleBanner);
	const addTrade = useJournal((s) => s.addTrade);
	const updateTrade = useJournal((s) => s.updateTrade);
	const deleteTrade = useJournal((s) => s.deleteTrade);
	const addRule = useJournal((s) => s.addRule);
	const updateRule = useJournal((s) => s.updateRule);
	const deleteRule = useJournal((s) => s.deleteRule);
	const toggleCheck = useJournal((s) => s.toggleCheck);
	const setStartingBalance = useJournal((s) => s.setStartingBalance);
	const loadSample = useJournal((s) => s.loadSample);
	const clearTrades = useJournal((s) => s.clearTrades);
	const dismissSample = useJournal((s) => s.dismissSample);
	const replaceAll = useJournal((s) => s.replaceAll);
	const [view, setView] = (0, import_react.useState)("overview");
	const [editing, setEditing] = (0, import_react.useState)(void 0);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)({
		q: "",
		result: "all",
		day: null
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground md:grid md:grid-cols-[15rem_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden border-r border-border md:sticky md:top-0 md:flex md:h-dvh md:flex-col md:px-4 md:py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-base font-medium tracking-tight",
							children: "Folio"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-subtle",
							children: "Private journal"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-8 grid gap-1",
						"aria-label": "Sections",
						children: NAV.map((item) => {
							const Icon = item.icon;
							const active = view === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-current": active ? "page" : void 0,
								onClick: () => setView(item.id),
								className: cn("press flex h-11 items-center gap-3 rounded-sm px-3 text-sm", active ? "bg-card-2 text-foreground" : "text-muted hover:bg-card hover:text-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setEditing(null),
								disabled: !ready,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Log a trade"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								onClick: () => setSettingsOpen(true),
								disabled: !ready,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), "Settings"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "px-3 text-sm text-subtle",
								children: "On this device"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 border-b border-border bg-background md:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex h-14 items-center justify-between gap-3 px-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base font-medium tracking-tight",
								children: "Folio"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "press inline-flex size-11 items-center justify-center rounded-sm text-muted",
								"aria-label": "Settings",
								onClick: () => setSettingsOpen(true),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "press inline-flex size-11 items-center justify-center rounded-sm bg-accent text-accent-foreground",
								"aria-label": "Log a trade",
								onClick: () => setEditing(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "grid grid-cols-4 border-t border-border",
						"aria-label": "Sections",
						children: NAV.map((item) => {
							const active = view === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-current": active ? "page" : void 0,
								onClick: () => setView(item.id),
								className: cn("h-11 text-sm", active ? "text-foreground" : "text-subtle"),
								children: item.label
							}, item.id);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto w-full max-w-5xl px-4 py-6 md:px-8 md:py-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-6 hidden items-center justify-between md:flex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-sm font-medium text-muted",
							children: {
								overview: "Overview",
								trades: "Trades",
								review: "Review",
								rules: "Rules"
							}[view]
						})
					}), !ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Opening your journal…"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						sampleBanner ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 flex flex-col gap-3 rounded-xl border border-border bg-card p-4 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Sample book, so the review has something to read. It is not your trading."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "secondary",
									onClick: clearTrades,
									children: "Start fresh"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: dismissSample,
									children: "Keep it"
								})]
							})]
						}) : null,
						view === "overview" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overview, {
							trades,
							rules,
							checks,
							startingBalance,
							onCreate: () => setEditing(null),
							onEdit: setEditing,
							onReviewRules: () => setView("rules")
						}) : null,
						view === "trades" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradesView, {
							trades,
							query,
							onQuery: setQuery,
							onEdit: setEditing
						}) : null,
						view === "review" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewView, {
							trades,
							onOpenDay: (day) => {
								setQuery({
									...query,
									day,
									result: "all",
									q: ""
								});
								setView("trades");
							}
						}) : null,
						view === "rules" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RulesView, {
							rules,
							checks,
							onToggle: toggleCheck,
							onAdd: addRule,
							onUpdate: updateRule,
							onDelete: deleteRule
						}) : null
					] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TradeDialog, {
				open: editing !== void 0,
				trade: editing ?? null,
				setups: [...new Set(trades.map((trade) => trade.setup).filter(Boolean))],
				onOpenChange: (open) => {
					if (!open) setEditing(void 0);
				},
				onSave: (next) => {
					if (trades.some((item) => item.id === next.id)) updateTrade(next);
					else addTrade(next);
				},
				onDelete: deleteTrade
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, {
				open: settingsOpen,
				onOpenChange: setSettingsOpen,
				startingBalance,
				backup: {
					version: 1,
					startingBalance,
					trades,
					rules,
					checks,
					sampleBanner
				},
				onBalance: setStartingBalance,
				onReplace: replaceAll,
				onClear: clearTrades,
				onSample: loadSample
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalApp, {});
}
//#endregion
export { Home as component };
